import React, { useState } from 'react'
import { Button } from '../components/Button.jsx'
import { Card } from '../components/Card.jsx'
import { Input } from '../components/Input.jsx'
import { Badge } from '../components/Badge.jsx'
import { Alert } from '../components/Alert.jsx'

export default function App() {
  const [dark, setDark] = useState(false)
  return (
    <div className={dark ? 'dark' : ''}>
      <div className="min-h-screen bg-[var(--bg)] text-[var(--fg)]">
        <header className="sticky top-0 bg-[var(--cream)]/80 backdrop-blur border-b border-nude/40">
          <div className="mx-auto max-w-6xl h-16 px-6 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 rounded-xl bg-olive" />
              <span className="font-semibold tracking-tight">Eirén</span>
            </div>
            <Button variant="outline" onClick={() => setDark(v => !v)}>{dark ? 'Light' : 'Dark'} mode</Button>
          </div>
        </header>

        <main className="mx-auto max-w-6xl px-6 py-10 space-y-10">
          <section className="rounded-3xl border border-nude/50 bg-gradient-to-b from-cream to-white p-10 shadow-mild">
            <Badge tone="nude">Modern Natural Luxury</Badge>
            <h1 className="mt-4 text-4xl md:text-5xl font-display font-semibold tracking-tight">Calm, crafted interfaces.</h1>
            <p className="mt-3/ text-[color:var(--fg)]/80">A Tailwind component kit in mellow nature tones.</p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Button size="lg">Explore components</Button>
              <Button variant="outline" size="lg">Secondary action</Button>
            </div>
          </section>

          <div className="grid md:grid-cols-3 gap-6">
            <Card title="Buttons" subtitle="Variants & states">
              <div className="flex flex-wrap gap-3">
                <Button>Primary</Button>
                <Button variant="secondary">Secondary</Button>
                <Button variant="accent">Accent</Button>
                <Button variant="outline">Outline</Button>
                <Button variant="ghost">Ghost</Button>
                <Button variant="dark">Dark</Button>
              </div>
            </Card>

            <Card title="Inputs" subtitle="Form controls">
              <div className="space-y-4">
                <Input label="Email" placeholder="you@brand.com" />
                <Input label="Promo code" placeholder="NATURAL-LUX" hint="Applied at checkout" />
                <div className="flex gap-3">
                  <Button className="flex-1">Submit</Button>
                  <Button variant="outline" className="flex-1">Cancel</Button>
                </div>
              </div>
            </Card>

            <Card title="Badges & Alerts" subtitle="Tone utilities">
              <div className="space-y-4">
                <div className="flex flex-wrap gap-2">
                  <Badge>Olive</Badge>
                  <Badge tone="sage">Sage</Badge>
                  <Badge tone="nude">Nude</Badge>
                  <Badge tone="indigo">Indigo</Badge>
                </div>
                <Alert title="Saved" description="Your preferences are preserved across devices." />
                <Alert tone="nude" title="Low stock" description="A few items remain in this collection." />
              </div>
            </Card>
          </div>
        </main>
      </div>
    </div>
  )
}
